module org.example.javafinalprojectapi {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires java.net.http;
    requires java.desktop;


    opens org.example.javafinalprojectapi to javafx.fxml;
    exports org.example.javafinalprojectapi;
}