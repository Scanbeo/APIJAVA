package org.example.javafinalprojectapi;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SearchController {

    // Declaring UI elements for search field and results list
    @FXML private TextField searchField;
    @FXML private ListView<String> searchResultsList;

    // Lists to store search results and their associated details
    private List<String> searchResults;
    private List<JsonObject> searchResultDetails;

    // Initializing controller and setting up event listeners
    @FXML public void initialize() {
        searchResults = new ArrayList<>();
        searchResultDetails = new ArrayList<>();

        // Adding a listener for list view selection changes
        searchResultsList.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue) -> {
            int selectedIndex = newValue.intValue();
            if (selectedIndex >= 0 && selectedIndex < searchResults.size()) {
                JsonObject trackObject = searchResultDetails.get(selectedIndex);
                openSongDetailsView(trackObject);
            }
        });
    }

    // Handling search button click
    @FXML public void search() {
        String query = searchField.getText().trim();
        if (!query.isEmpty()) {
            String searchResultsJson = LastFmAPI.searchTrack(query);
            if (searchResultsJson != null) {
                parseSearchResults(searchResultsJson);
                searchResultsList.getItems().setAll(searchResults);
                searchResultsList.setVisible(true);
            } else {
                searchResultsList.getItems().clear();
                searchResultsList.setVisible(false);
            }
        }
    }

    // Parsing JSON results and extracting track information
    private void parseSearchResults(String searchResultsJson) {
        searchResults.clear();
        searchResultDetails.clear();

        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(searchResultsJson, JsonObject.class);
        JsonObject resultsObject = jsonObject.getAsJsonObject("results");
        JsonObject trackMatches = resultsObject.getAsJsonObject("trackmatches");
        JsonArray trackArray = trackMatches.getAsJsonArray("track");

        for (JsonElement element : trackArray) {
            JsonObject trackObject = element.getAsJsonObject();
            String formattedResult = trackObject.get("name").getAsString() + " - " + trackObject.get("artist").getAsString();
            searchResults.add(formattedResult);
            searchResultDetails.add(trackObject);
        }
    }

    // Opening a new window to display song details
    private void openSongDetailsView(JsonObject trackObject) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/javafinalprojectapi/song-details-view.fxml"));
            Parent root = loader.load();

            SongDetailsController controller = loader.getController();
            String title = trackObject.get("name").getAsString();
            String artist = trackObject.get("artist").getAsString();
            String album = trackObject.has("album") ? trackObject.get("album").getAsString() : "Unknown";
            String url = trackObject.has("url") ? trackObject.get("url").getAsString() : "Unknown";

            controller.initialize(title, artist, album, url);

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Song Details");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
