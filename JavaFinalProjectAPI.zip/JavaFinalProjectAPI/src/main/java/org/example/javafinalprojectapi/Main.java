package org.example.javafinalprojectapi;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {

    /**
     * The main entry point for the application.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Launching the JavaFX application
        launch(args);
    }

    /**
     * Starts the application by loading the initial view and setting up the stage.
     *
     * @param primaryStage the primary stage for the application
     * @throws IOException if an error occurs loading the FXML file
     */
    @Override
    public void start(Stage primaryStage) throws IOException {
        // Loading the main FXML layout
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/javafinalprojectapi/hello-view.fxml"));
        Parent root = loader.load();

        // Setting the application icon
        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/org/example/javafinalprojectapi/icon.png")));

        // Setting the stage title
        primaryStage.setTitle("SONG DETAILS");

        // Creating a scene with the loaded layout and applying CSS styling
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/org/example/javafinalprojectapi/styles.css").toExternalForm());

        // Setting the scene and showing the stage
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
