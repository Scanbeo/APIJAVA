package org.example.javafinalprojectapi;

import javafx.fxml.FXML;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class SongDetailsController {

    // FXML elements for displaying song details
    @FXML private Label songTitleLabel;
    @FXML private Label songArtistLabel;
    @FXML private Label songAlbumLabel;
    @FXML private Hyperlink songUrlLabel;

    /**
     * Initializes the controller with song details.
     *
     * @param title The title of the song.
     * @param artist The artist of the song.
     * @param album The album the song is from (if available).
     * @param url The URL associated with the song (if available).
     */
    public void initialize(String title, String artist, String album, String url) {

        // Setting labels with formatted song information
        songTitleLabel.setText("TITLE: " + title);
        songArtistLabel.setText("ARTIST: " + artist);
        songAlbumLabel.setText("ALBUM: " + album);

        // Setting hyperlink text and adding click listener
        songUrlLabel.setText("URL: " + url);
        songUrlLabel.setOnAction(e -> openWebpage(url));
    }

    /**
     * Closes the song details window.
     */
    @FXML
    public void closeDetailsView() {
        songTitleLabel.getScene().getWindow().hide();
    }

    /**
     * Attempts to open the provided URL in the user's web browser.
     *
     * @param url The URL to open.
     */
    private void openWebpage(String url) {
        if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
            try {
                Desktop.getDesktop().browse(new URI(url));
            } catch (IOException | URISyntaxException e) {
                e.printStackTrace();
                // Handle the case where opening the URL fails (e.g., show an error message)
            }
        } else {
            // Handle the case where the platform doesn't support opening a web browser
            System.out.println("Failed to open webpage. Your platform may not support it.");
        }
    }
}
