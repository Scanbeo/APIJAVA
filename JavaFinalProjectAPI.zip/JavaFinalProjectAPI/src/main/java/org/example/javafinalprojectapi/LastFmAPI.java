package org.example.javafinalprojectapi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class LastFmAPI {

    // Storing the API key securely as a constant
    private static final String apiKey = "f670c24001e6c5d4d823e239027c2421";

    /**
     * Searches for a track on Last.fm using their API.
     *
     * @param trackName The name of the track to search for.
     * @return The JSON response from the API, or null if the request failed.
     */
    public static String searchTrack(String trackName) {
        try {
            // Creating the API request URL with necessary parameters
            String apiMethod = "track.search";
            String url = "http://ws.audioscrobbler.com/2.0/?method=" + apiMethod + "&track=" + trackName + "&api_key=" + apiKey + "&format=json";

            // Using a HttpClient for making HTTP requests
            HttpClient httpClient = HttpClient.newHttpClient();

            // Building a GET request with the constructed URL
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();

            // Sending the request and receiving the response
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            // Checking for a successful response
            if (response.statusCode() == 200) {
                // Returning the JSON response body if successful
                return response.body();
            } else {
                // Logging an error for failed requests
                System.err.println("HTTP request failed with status code: " + response.statusCode());
                return null;
            }

        } catch (IOException | InterruptedException e) {
            // Printing a stack trace for any exceptions
            e.printStackTrace();
            return null;
        }
    }
}
